# import random

class Round:
    def __init__(self, name, start_time, end_time, matches=None):
        # initialisation des attributs
        pass

# Logique de gestion des rounds
# Créez des instances de tour et de matchs
# Générez les paires pour chaque round en fonction du score des joueurs
# Mettez à jour les points des joueurs après chaque round
# Répétez le processus jusqu'à la fin du tournoi